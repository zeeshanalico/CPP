//#include "ArrayClass.h"
#include"iostream"